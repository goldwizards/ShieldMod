using Terraria.ModLoader;

namespace ShieldMod
{
    public class ShieldMod : Mod
    {
        // 완전히 비워둬도 괜찮음
    }
}
